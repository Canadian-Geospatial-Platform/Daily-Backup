<?php
/**
 * Template Name: Blog Archive 3
 *
 * 
 * @package    Auxin
 * @author     averta (c) 2014-2020
 * @link       http://averta.net
 */

locate_template( 'templates/blog-main.php', true );
